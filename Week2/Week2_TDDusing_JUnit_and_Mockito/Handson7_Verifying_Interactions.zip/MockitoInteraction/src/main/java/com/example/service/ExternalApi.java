package com.example.service;

public interface ExternalApi {
	void getData();

}
