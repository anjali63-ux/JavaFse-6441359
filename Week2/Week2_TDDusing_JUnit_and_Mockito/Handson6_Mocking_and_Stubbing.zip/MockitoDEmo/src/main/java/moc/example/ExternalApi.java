package moc.example;

public interface ExternalApi {
	string getData();

}
